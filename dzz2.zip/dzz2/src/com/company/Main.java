package com.company;

public class Main {

    public static void main(String[] args) {
        goldAll(22, 15);
        screen(1,2,"Спать хочу завтра на работу");
        screen(1,2,"Спать хочу завтра на работу");
        screen(1,2,"Спать хочу завтра на работу");
        screen(1,2,"Спать хочу завтра на работу");
        screen(1,2,"Спать хочу завтра на работу");



    }

    public static void goldAll(int age, int temperature) {
        System.out.println("Возраст" + " " + age + " " + "Температура на улице" + " " + temperature);
        boolean isRainy = true;

//       true && true&& true && true = 1*1*1*1 == true
        if (age >= 20 && age <= 45 && temperature >= -20 && temperature <= 30) {
            System.out.println("Можно идти гулять");

//  true && true && true && true = 1*1*1*1 == true
        } else if (age > 20 && temperature >= 0 && temperature <= 28) {
            System.out.println("Можно идти гулять");
//         true
        } else if (age > 45) {
            System.out.println("Можно идти гулять");
        }
           else {
            System.out.println("Оставайтесь дома");
        }
    }
public static void screen (int sc,int skk,String skkk){
    System.out.println("Время уже" + " " + sc + " а я буду спать в " + " " + skk+ " ");
    System.out.println(skkk);
}

}